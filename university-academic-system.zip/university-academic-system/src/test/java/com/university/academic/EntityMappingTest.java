package com.university.academic;

import com.university.academic.model.*;
import com.university.academic.repository.*;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.annotation.Commit;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.UUID;

import static org.junit.jupiter.api.Assertions.*;

/**
 * Boots the context (Hibernate generates the tables in university_academic_db)
 * and saves a small object graph to verify every relationship mapping.
 * Remove @Commit if you want the sample rows rolled back after the test.
 */
@SpringBootTest
@Transactional
@Commit
class EntityMappingTest {

    @Autowired DepartmentRepository departmentRepository;
    @Autowired LecturerRepository lecturerRepository;
    @Autowired StudentRepository studentRepository;
    @Autowired StudentProfileRepository profileRepository;
    @Autowired CourseRepository courseRepository;
    @Autowired RegistrationRepository registrationRepository;

    @Test
    void relationshipsArePersistedCorrectly() {
        String s = UUID.randomUUID().toString().substring(0, 6);

        Department dept = departmentRepository.save(new Department("Information Systems " + s, "IS" + s));

        Lecturer head = lecturerRepository.save(new Lecturer("Alice", "Mukamana", "alice." + s + "@uni.rw", dept));
        dept.setHead(head);
        departmentRepository.save(dept);

        Course course = courseRepository.save(new Course("WT" + s, "Web Technology", 3, dept));
        head.addCourse(course);
        lecturerRepository.save(head);

        Student student = new Student("REG" + s, "Joshua", "Student", "student." + s + "@uni.rw",
                LocalDate.of(2024, 9, 1), dept);
        student.setProfile(new StudentProfile(LocalDate.of(2004, 5, 12), Gender.MALE, "+250788000000", "Kigali, Rwanda"));
        student = studentRepository.save(student);

        Registration reg = new Registration(student, course, LocalDate.now(), "2026/2027", Semester.FIRST);
        reg.setStatus(RegistrationStatus.APPROVED);
        reg.setGrade(new BigDecimal("85.50"));
        registrationRepository.save(reg);

        assertNotNull(dept.getHead());
        assertEquals(1, courseRepository.findByLecturersId(head.getId()).size());
        assertTrue(profileRepository.findByStudentId(student.getId()).isPresent());
        assertEquals(1, registrationRepository.findByStudentId(student.getId()).size());
        assertEquals(RegistrationStatus.APPROVED, registrationRepository.findByCourseId(course.getId()).get(0).getStatus());
    }
}

package com.university.academic.model;

import jakarta.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "departments")
public class Department {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true, length = 100)
    private String name;

    @Column(nullable = false, unique = true, length = 20)
    private String code;

    // One-to-One: each department has exactly one head lecturer (FK in departments table)
    @OneToOne
    @JoinColumn(name = "head_lecturer_id", unique = true)
    private Lecturer head;

    // One-to-Many: a department employs many lecturers (FK lives in lecturers.department_id)
    @OneToMany(mappedBy = "department")
    private Set<Lecturer> lecturers = new HashSet<>();

    // One-to-Many: a department admits many students
    @OneToMany(mappedBy = "department")
    private Set<Student> students = new HashSet<>();

    // One-to-Many: a department offers many courses
    @OneToMany(mappedBy = "department")
    private Set<Course> courses = new HashSet<>();

    public Department() {}

    public Department(String name, String code) {
        this.name = name;
        this.code = code;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }
    public String getName() { return name; }
    public void setName(String name) { this.name = name; }
    public String getCode() { return code; }
    public void setCode(String code) { this.code = code; }
    public Lecturer getHead() { return head; }
    public void setHead(Lecturer head) { this.head = head; }
    public Set<Lecturer> getLecturers() { return lecturers; }
    public void setLecturers(Set<Lecturer> lecturers) { this.lecturers = lecturers; }
    public Set<Student> getStudents() { return students; }
    public void setStudents(Set<Student> students) { this.students = students; }
    public Set<Course> getCourses() { return courses; }
    public void setCourses(Set<Course> courses) { this.courses = courses; }
}

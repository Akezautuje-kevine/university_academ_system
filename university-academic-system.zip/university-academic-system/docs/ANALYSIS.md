# Problem Analysis and Design

## 1. Entities (and why)

| Entity | Why it is an entity |
|---|---|
| **Department** | Core organisational unit; owns courses, lecturers, students and has a head. |
| **Lecturer** | Employed by a department, teaches courses, may head a department. |
| **Student** | Admitted into a department; registers for courses. |
| **StudentProfile** | Personal details (DOB, gender, phone, address), kept separate from Student; exactly one per student. |
| **Course** | Offered by one department, taught by lecturers, taken by students. |
| **Registration** | Join entity for Student–Course: the relationship itself holds data (date, academic year, semester, status, grade). |

The Lecturer–Course assignment is **not** an entity: it is a plain join table (`lecturer_courses`) because it carries no extra data.

## 2. Attributes

- **Department**: id (PK), name, code, head_lecturer_id (FK)
- **Lecturer**: id (PK), first_name, last_name, email, department_id (FK)
- **Student**: id (PK), registration_number, first_name, last_name, email, admission_date, department_id (FK)
- **StudentProfile**: id (PK), date_of_birth, gender, phone_number, residential_address, student_id (FK, unique)
- **Course**: id (PK), code, title, credits, department_id (FK)
- **Registration**: id (PK), student_id (FK), course_id (FK), registration_date, academic_year, semester, status (PENDING/APPROVED/REJECTED), grade
- **lecturer_courses** (join table): lecturer_id (FK), course_id (FK), composite PK

## 3. Relationships and cardinality

| # | Relationship | Cardinality | Implemented with |
|---|---|---|---|
| 1 | Department employs Lecturer | 1 : N | FK `lecturers.department_id` |
| 2 | Department is headed by Lecturer | 1 : 1 | FK `departments.head_lecturer_id` (unique) |
| 3 | Department admits Student | 1 : N | FK `students.department_id` |
| 4 | Department offers Course | 1 : N | FK `courses.department_id` |
| 5 | Student has StudentProfile | 1 : 1 | FK `student_profiles.student_id` (unique) |
| 6 | Lecturer teaches Course | M : N | **Join table** `lecturer_courses` |
| 7 | Student registers for Course | M : N | **Join entity** `Registration` (two 1:N relationships) |

## 4. Answers to the design checklist

- **Foreign keys needed:** relationships 1, 2, 3, 4, 5 (and the two FKs inside Registration).
- **Join table needed:** Lecturer–Course (`lecturer_courses`), no extra attributes.
- **Join entity needed:** Student–Course (`Registration`), because it stores date, year, semester, status and grade.
- **Why the FK sits where it does:** the FK goes on the "many" side of a 1:N; for 1:1 it goes on the dependent side (profile depends on student; head is an attribute of the department).
- A unique constraint on `(student_id, course_id, academic_year, semester)` prevents duplicate registrations for the same term.

## 5. ERD

```mermaid
erDiagram
    DEPARTMENT ||--o{ LECTURER : employs
    DEPARTMENT |o--|| LECTURER : "headed by"
    DEPARTMENT ||--o{ STUDENT : admits
    DEPARTMENT ||--o{ COURSE : offers
    STUDENT ||--|| STUDENT_PROFILE : has
    LECTURER }o--o{ COURSE : "teaches (lecturer_courses)"
    STUDENT ||--o{ REGISTRATION : makes
    COURSE ||--o{ REGISTRATION : "is registered in"

    DEPARTMENT {
        bigint id PK
        varchar name
        varchar code
        bigint head_lecturer_id FK
    }
    LECTURER {
        bigint id PK
        varchar first_name
        varchar last_name
        varchar email
        bigint department_id FK
    }
    STUDENT {
        bigint id PK
        varchar registration_number
        varchar first_name
        varchar last_name
        varchar email
        date admission_date
        bigint department_id FK
    }
    STUDENT_PROFILE {
        bigint id PK
        date date_of_birth
        varchar gender
        varchar phone_number
        varchar residential_address
        bigint student_id FK
    }
    COURSE {
        bigint id PK
        varchar code
        varchar title
        int credits
        bigint department_id FK
    }
    REGISTRATION {
        bigint id PK
        bigint student_id FK
        bigint course_id FK
        date registration_date
        varchar academic_year
        varchar semester
        varchar status
        numeric grade
    }
    LECTURER_COURSES {
        bigint lecturer_id PK
        bigint course_id PK
    }
```

## 6. Relational schema

```
departments       (id PK, name UNIQUE, code UNIQUE, head_lecturer_id FK -> lecturers.id UNIQUE)
lecturers         (id PK, first_name, last_name, email UNIQUE, department_id FK -> departments.id)
students          (id PK, registration_number UNIQUE, first_name, last_name, email UNIQUE,
                   admission_date, department_id FK -> departments.id)
student_profiles  (id PK, date_of_birth, gender, phone_number, residential_address,
                   student_id FK -> students.id UNIQUE)
courses           (id PK, code UNIQUE, title, credits, department_id FK -> departments.id)
lecturer_courses  (lecturer_id FK -> lecturers.id, course_id FK -> courses.id, PK(lecturer_id, course_id))
registrations     (id PK, student_id FK -> students.id, course_id FK -> courses.id,
                   registration_date, academic_year, semester, status, grade,
                   UNIQUE(student_id, course_id, academic_year, semester))
```
